import requests, time
from utils import Helper
import pandas as pd
utils = Helper()

path = r"LEI_COMP.xlsx"
df = pd.read_excel(path)
# df.head(10)
companies = df["Co Name"].to_list()
# print(len(companies))

s = requests.Session()
headers = {"User-Agent": "Mozilla/5.0","Accept": "application/json",}
s.get("https://www.legalentityidentifier.in/leicert/",headers=headers,verify=False,)

failed = []
for idx,company in enumerate(companies[10000:]):
    
    if idx%1000 == 0:
        s = requests.Session()
        s.get("https://www.legalentityidentifier.in/leicert/",headers=headers,verify=False,)
    
    print(f"{idx + 1 }..")
    r = s.get(
        "https://api-india.companydata.io/api/v1/fuzzycompletions",
        params={
            "field": "fulltext",
            "country": "in",
            "q":company,
        },
        headers=headers,
        verify=False,
    )

    print("Status:", r.status_code)
    # print(r.json())
    if r.status_code == 200:
        temp = r.json()
        utils.save_json(temp,f"files/{company}.json")
        
    else:
        failed.append(company)
        print(f"it failed: {company}")
    time.sleep(.5)